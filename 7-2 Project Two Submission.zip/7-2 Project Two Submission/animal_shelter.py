from pymongo import MongoClient
from bson import ObjectId
import logging
from pymongo.errors import DuplicateKeyError

class AnimalShelter:
    def __init__(self):
        # MongoDB connection details
        USER, PASS, HOST, PORT, DB, COL = 'aacuser', 'SNHU1234', 'nv-desktop-services.apporto.com', 30318, 'AAC', 'animals'
        try:
            # Establish connection to MongoDB
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
            print("Database connection successful.")
        except Exception as e:
            print(f"Error connecting to the database: {e}")
        
        # Set up logging for tracking actions
        logging.basicConfig(filename='animal_shelter.log', level=logging.INFO, format='%(asctime)s - %(message)s')

    def log(self, message):
        """Log action messages to both file and console."""
        logging.info(message)
        print(message)

    def close(self):
        """Close the MongoDB connection."""
        self.client.close()
        print("Database connection closed.")
    
    def validate_animal_data(self, data):
        """Validate required fields in the input data."""
        required_fields = ['name', 'age', 'species']
        for field in required_fields:
            if field not in data:
                raise ValueError(f"Missing required field: {field}")
        return True

    def format_objectid(self, document):
        """Convert MongoDB ObjectId to string for better readability."""
        if '_id' in document:
            document['_id'] = str(document['_id'])
        return document

    def create(self, data):
        """Insert a new animal record into the MongoDB collection."""
        if isinstance(data, dict) and data:
            try:
                self.validate_animal_data(data)
                self.collection.insert_one(data)
                print("Document inserted:", data)
                self.log(f"Document inserted: {data}")
                return True
            except (DuplicateKeyError, ValueError) as e:
                print(f"Error: {e}")
                self.log(f"Error inserting document: {e}")
                return False
        else:
            print("Invalid data input.")
            self.log("Invalid data input for document creation.")
            return False

    def read(self, query={}):
        """
        Retrieve documents from MongoDB collection based on the provided query.
        
        Args:
            query (dict): MongoDB query to filter documents (default is empty dictionary, meaning fetch all records).
        
        Returns:
            list: A list of documents that match the query. Each document will have the '_id' field formatted as a string.
        """
        if isinstance(query, dict):
            try:
                results = list(self.collection.find(query))  # Fetch records from MongoDB
                # Format the ObjectId for readability
                results = [self.format_objectid(record) for record in results]
                return results
            except Exception as e:
                print(f"Error retrieving data: {e}")
                self.log(f"Error retrieving data: {e}")
                return []
        else:
            print("Query must be a dictionary.")
            self.log("Query for reading data must be a dictionary.")
            return []

    def update(self, query, update_data):
        """Update documents that match the query."""
        if isinstance(query, dict) and isinstance(update_data, dict):
            try:
                result = self.collection.update_many(query, {'$set': update_data})
                updated_count = result.modified_count
                self.log(f"Updated {updated_count} records with query: {query}")
                return updated_count
            except Exception as e:
                print(f"Error updating data: {e}")
                self.log(f"Error updating data: {e}")
                return 0
        else:
            print("Query and update_data must be dictionaries.")
            self.log("Query and update_data must be dictionaries for updating.")
            return 0

    def delete(self, query):
        """Delete documents that match the query."""
        if isinstance(query, dict):
            try:
                result = self.collection.delete_many(query)
                deleted_count = result.deleted_count
                self.log(f"Deleted {deleted_count} records with query: {query}")
                return deleted_count
            except Exception as e:
                print(f"Error deleting data: {e}")
                self.log(f"Error deleting data: {e}")
                return 0
        else:
            print("Query must be a dictionary.")
            self.log("Query for deleting data must be a dictionary.")
            return 0
